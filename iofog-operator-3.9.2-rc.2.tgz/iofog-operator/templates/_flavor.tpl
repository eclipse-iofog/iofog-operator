{{/*
Flavor defaults written by hack/package-helm.sh for iofog.
*/}}
{{- define "iofog-operator.crdGroup" -}}iofog.org{{- end }}
{{- define "iofog-operator.controlPlaneName" -}}iofog{{- end }}
{{- define "iofog-operator.operatorImageDefault" -}}ghcr.io/eclipse-iofog/operator:3.9.2-rc.2{{- end }}
